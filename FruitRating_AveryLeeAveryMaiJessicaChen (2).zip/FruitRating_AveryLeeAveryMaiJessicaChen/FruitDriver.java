/**
 * Teacher: Ms. Krasteva
 * Assignment: This program ranks a large variety of fruits with five different categories to place them in and
 * calculates weighted averages
 * @author Avery Mai, Avery Lee, Jessica Chen
 * @version 03/03/2023
 */
 
 public class FruitDriver extends Fruit {

    /**
     * Main method for part 1 of the assignment
     * Calls methods from Fruit class
     */
    public static void main(String[]args){
        Fruit f = new Fruit();
        f.displayTitle();
        f.mainMenu();
    }
}
