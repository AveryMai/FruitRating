
/**
 * Teacher: Ms. Krasteva
 * Assignment: This program ranks a large variety of fruits with five different categories to place them in and
 * calculates weighted averages
 * @author Avery Mai, Avery Lee, Jessica Chen
 * @version 03/03/2023
 */

import java.util.*; // imports the scanner class
import java.lang.Math; // imports the math class
import java.io.*; // imports the file and FileNotFound classes

public class Fruit2 {

    /**
     * The beginning of the program, with class name "Fruit"
     * Makes the file 'FruitText.txt' accessible for the class
     */
    File fruitText = new File("FruitText.txt");

    /**
     * The scanner is named and variables are declared and assigned
     */
    Scanner sc = new Scanner(System.in);
    private int place;
    private boolean run = true;
    public int select;
    private int[][] fruitData = new int [5][10];
    private String[] fruitNames = new String [10];

    /**
     * class constructor
     */
    public Fruit2() {
    }

    /**
     * method 'fromFile'
     * reads the data in the 'FruitText.txt' file and writes the data to an array
     */
    public void fromFile() {
        try {
            Scanner txtReader = new Scanner(fruitText);
            /* writes the names of the fruits to a 1D array called 'fruitNames' */
            for(int i = 0; i < 1; i++) {
                String txtData = txtReader.nextLine();
                fruitNames = txtData.split(", ");
            }
            /** writes the ratings of the fruits to a 2D array called 'fruitData' 
             *  the rows contain the values of sweetness, affordability, availability, accessibility, nutrition respectively
             *  the columns are the individual values of sweetness, affordability, availability, accessibility, nutrition of each fruit with the corresponding index
             */
            while(txtReader.hasNextLine())   {
                for (int j = 0; j < fruitData.length; j++) {
                    String[] a = txtReader.nextLine().split(", ");
                    for (int k = 0; k < a.length; k++) {
                        fruitData[j][k] = Integer.parseInt(a[k]);
                    }
                }
            }
            txtReader.close();
        } 
        /* catches the FileNotFoundException, which would occur if the FruitText.txt file was not in the same directory */
        catch (FileNotFoundException e) {
            System.out.println("No such file exists, please try again");
            e.printStackTrace();
        }
    }

    /**
     * displayTitle method
     * Informs user the intention of this program, including the ranking system and weighted average formula
     */
    public void displayTitle() {
        System.out.println("Welcome to the fruit rater!");
        System.out.print("This program will calculate the rating of fruits based on sweetness (a), ");
        System.out.print("affordability (b), availability (c), accessibility (d), and nutrition");
        System.out.println("(e) on a scale from 1 to 10.");
        System.out.println();
        System.out.print("The formula is: (0.3*a + 0.2*b + 0.1*c + 0.2*d + 0.2*e).");
    }

    /**
     * mainMenu method
     * Displays the main menu for the user
     */
    public void mainMenu() {
        /**
         * while loop to run mainMenu and option methods repeatedly
         * operates if run boolean reamins true
         * closes loop when user selects exit option, run boolean set to false
         */
        while (run) {
            System.out.println();
            System.out.println();
            System.out.println("Please input an option:");
            System.out.println("0 - Display all fruits");
            System.out.println("1 - Display highest rating in sweetness");
            System.out.println("2 - Display highest rating in affordability");
            System.out.println("3 - Display highest rating in availability");
            System.out.println("4 - Display highest rating in accessibility");
            System.out.println("5 - Display highest rating in nutrition");
            System.out.println("6 - Display highest rated fruit overall");
            System.out.println("7 - Exit program");
            System.out.println();

            /* call userinput method to recieve integer via scanner */
            select = userInput();

            if (select == 0) { // allows the user to choose an option from the menu and calls the corresponding method
                displayAll();
            } else if (select == 1) {
                displayTaste();
            } else if (select == 2) {
                displayPrice();
            } else if (select == 3) {
                displayAccessibility();
            } else if (select == 4) {
                displayAvailability();
            } else if (select == 5) {
                displayNutrition();
            } else if (select == 6) {
                displayBest();
            } else if (select == 7) {
                exit();
                run = false;
            } else {
                System.out.println("Please choose a correct option");
            }
        }
    }

    /**
     * userInput method
     * @return the user's selection, which will correspond to an option on the menu
     */
    public int userInput() {
        System.out.print("Selection: ");
        return sc.nextInt();
    }

    /**
     * displayAll method
     * Prints out all the fruits with their 5 categories ranked and overall average
     */
    public void displayAll() {
        System.out.println();
        for (int i = 0; i < fruitNames.length; i++) {
            System.out.print(fruitNames[i]); 
            System.out.print(":");
            if (fruitNames[i].length() < 6)
            System.out.print("\t");
            System.out.print(" \t Sweetness: " + fruitData[0][i]);
            System.out.print(" \t Affordability: " + fruitData[1][i]);
            System.out.print(" \t Accessibility: " + fruitData[2][i]);
            System.out.print(" \t Availability: " + fruitData[3][i]);
            System.out.print(" \t Nutrition: " + fruitData[4][i]);
            System.out.print(" \t Overall: ");
            System.out.print(Math.round((0.3 * fruitData[0][i] + 0.2 * fruitData[1][i] + 0.1 * fruitData[2][i]
                    + 0.2 * fruitData[3][i] + 0.2 * fruitData[4][i]) * 100.0) / 100.0);
            System.out.println();
        }
    }

    /**
     * displayTaste method
     * Prints out the sweetest fruit
     */
    public void displayTaste() {
        System.out.println();
        place = 0;
        for (int i = 0; i < fruitNames.length; i++) {
            if (fruitData[0][place] < fruitData[0][i])
                place = i;
        }
        System.out.print("The sweetest fruit is: ");
        displayFruit();
        System.out.println();
    }

    /**
     * displayPrice method
     * Prints out the most affordable fruit
     */
    public void displayPrice() {
        System.out.println();
        place = 0;
        for (int i = 0; i < fruitNames.length; i++) {
            if (fruitData[1][place] < fruitData[1][i])
                place = i;
        }
        System.out.print("The most affordable fruit is: ");
        displayFruit();
        System.out.println();
    }

    /**
     * displayAccessibility method
     * Prints out the most accessible fruit (ie. the easiest to be eaten)
     */
    public void displayAccessibility() {
        System.out.println();
        place = 0;
        for (int i = 0; i < fruitNames.length; i++) {
            if (fruitData[2][place] < fruitData[2][i])
                place = i;
        }
        System.out.print("The most accessible fruit is: ");
        displayFruit();
        System.out.println();
    }

    /**
     * displayAvailability method
     * Prints out the most available fruit (ie. the easiest to find in a grocery
     * store)
     */
    public void displayAvailability() {
        System.out.println();
        place = 0;
        for (int i = 0; i < fruitNames.length; i++) {
            if (fruitData[3][place] < fruitData[3][i])
                place = i;
        }
        System.out.print("The most widely available fruit is: ");
        displayFruit();
        System.out.println();
    }

    /**
     * displayNutrition method
     * Prints out the most nutritious fruit
     */
    public void displayNutrition() {
        System.out.println();
        place = 0;
        for (int i = 0; i < fruitNames.length; i++) {
            if (fruitData[4][place] < fruitData[4][i])
                place = i;
        }
        System.out.print("The most nutritious fruit is: ");
        displayFruit();
        System.out.println();
    }

    /**
     * displayBest method
     * Prints out the overall best fruit (most well rounded) by calculating the
     * weighted average
     */
    public void displayBest() {
        System.out.println();
        place = 0;
        double val = 0;
        for (int i = 0; i < fruitNames.length; i++) {
            val = (0.3 * fruitData[0][place] + 0.2 * fruitData[1][place] + 0.1 * fruitData[2][place] + 0.2 * fruitData[3][place] + 0.2 * fruitData[4][place]);
            if (val < (0.3 * fruitData[0][i] + 0.2 * fruitData[1][i] + 0.1 * fruitData[2][i] + 0.2 * fruitData[3][i] + 0.2 * fruitData[4][i]))
                place = i;
        }
        System.out.print("The most well-rounded fruit is: ");
        displayFruit();
        System.out.println();
    }

    /**
     * displayFruit method
     * Prints the information about the pre-chosen fruit
     */
    public void displayFruit() {
        System.out.println();
        System.out.println(fruitNames[place]);
        System.out.println("Sweetness: " + fruitData[0][place]);
        System.out.println("Affordability: " + fruitData[1][place]);
        System.out.println("Accessibility: " + fruitData[2][place]);
        System.out.println("Availability: " + fruitData[3][place]);
        System.out.println("Nutrition: " + fruitData[4][place]);
        System.out.print("Overall Score: ");
        System.out.print(Math.round((0.3 * fruitData[0][place] + 0.2 * fruitData[1][place] + 0.1 * fruitData[2][place]
                + 0.2 * fruitData[3][place] + 0.2 * fruitData[4][place]) * 100.0) / 100.0);
    }

    /**
     * exit method
     * Exits the program and prints a message for the user
     */
    public void exit() {
        System.out.println();
        System.out.println("Thanks for using the program!");
        System.out.println("Made by Avery Lee, Avery Mai, and Jessica Chen");
        System.out.println("03/02/2023");
    }
} // ending of the program