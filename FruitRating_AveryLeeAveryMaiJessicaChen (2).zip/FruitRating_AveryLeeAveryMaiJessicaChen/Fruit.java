/**
 * Teacher: Ms. Krasteva
 * Assignment: This program ranks a large variety of fruits with five different categories to place them in and
 * calculates weighted averages
 * @author Avery Mai, Avery Lee, Jessica Chen
 * @version 03/03/2023
 */

 import java.util.Scanner; //imports scanner
 import java.lang.Math; //imports the math class
 
 public class Fruit {
 
     /**
      * The beginning of the program, with class name "Fruit"
      * The scanner is named and variables are declared and assigned
      */
     Scanner sc = new Scanner(System.in);
     private int place;
     private String[] fruits = {"Mango", "Bittermelon", "Kiwi", "Durian", "Grapes", "Banana", "Grapefruit", "Blackberry", "Apple", "Cherries"};
     private int[] sweetness = {9, 1, 6, 2, 10, 8, 4, 3, 7, 5};
     private int[] affordability = {7, 6, 5, 1, 3, 10, 9, 1, 8, 4};
     private int[] accessibility = {3, 2, 5, 1, 8, 6, 4, 10, 9, 7};
     private int[] availability = {4, 2, 7, 1, 8, 9, 5, 3, 10, 6};
     private int[] nutrition = {6, 2, 8, 1, 5, 9, 7, 3, 10, 4};
     private boolean run = true;
     public int select;
 
 
     /**
      * Class constructor
      */
     public Fruit () {
     }
 
 
     /**
      * displayTitle method
      * Informs user the intention of this program, including the ranking system and weighted average formula
      */
     public void displayTitle() {
         System.out.println("Welcome to the fruit rater!");
         System.out.print("This program will calculate the rating of fruits based on sweetness (a), ");
         System.out.print("affordability (b), availability (c), accessibility (d), and nutrition");
         System.out.println("(e) on a scale from 1 to 10.");
         System.out.println();
         System.out.print("The formula is: (0.3*a + 0.2*b + 0.1*c + 0.2*d + 0.2*e).");
     }
 
 
     /**
      * mainMenu method
      * Displays the main menu for the user
      */
     public void mainMenu() {
         while (run) {
             System.out.println();
             System.out.println();
             System.out.println("Please input an option:");
             System.out.println("0 - Display all fruits");
             System.out.println("1 - Display highest rating in sweetness");
             System.out.println("2 - Display highest rating in affordability");
             System.out.println("3 - Display highest rating in availability");
             System.out.println("4 - Display highest rating in accessibility");
             System.out.println("5 - Display highest rating in nutrition");
             System.out.println("6 - Display highest rated fruit overall");
             System.out.println("7 - Exit program");
             System.out.println();
 
 
             select = userInput();
 
 
             if(select == 0) { //allows the user to choose an option from the menu and calls the corresponding method
                 displayAll();
             } else if (select == 1) {
                 displayTaste();
             } else if (select == 2) {
                 displayPrice();
             } else if (select == 3) {
                 displayAccessibility();
             } else if (select == 4) {
                 displayAvailability();
             } else if (select == 5) {
                 displayNutrition();
             } else if (select == 6) {
                 displayBest();
             } else if (select == 7) {
                 exit();
                 run = false;
             } else {
                 System.out.println("Please choose a correct option");
             }
         }
     }
    
     /**
      * userInput method
      * @return the user's selection, which will correspond to an option on the menu
      */
     public int userInput(){
         System.out.print("Selection: ");
         return sc.nextInt();
     }
  
     /**
      * displayAll method
      * Prints out all the fruits with their 5 categories ranked and overall average
      */
     public void displayAll(){
         System.out.println();
         for(int i = 0; i < fruits.length; i++) {
             System.out.print(fruits[i]);
             System.out.print(":");
             if(fruits[i].length() < 7) System.out.print("\t");
             System.out.print("\t Sweetness: " + sweetness[i]);
             System.out.print(" \t Affordability: " + affordability[i]);
             System.out.print(" \t Accessibility: " + accessibility[i]);
             System.out.print(" \t Availability: " + availability[i]);
             System.out.print(" \t Nutrition: " + nutrition[i]);
             System.out.print(" \t Overall: ");
             System.out.print(Math.round((0.3*sweetness[i] + 0.2*affordability[i] + 0.1*accessibility[i] + 0.2*availability[i] + 0.2*nutrition[i])* 100.0) / 100.0);
             System.out.println();
         }
     }
 
 
     /**
      * displayTaste method
      * Prints out the sweetest fruit
      */
     public void displayTaste() {
         System.out.println();
         place = 0;
         for(int i = 0; i < fruits.length; i++ ) {
             if(sweetness[place] < sweetness[i]) place = i;
         }
         System.out.print("The sweetest fruit is: ");
         displayFruit();
         System.out.println();
     }
 
 
     /**
      * displayPrice method
      * Prints out the most affordable fruit
      */
     public void displayPrice() {
         System.out.println();
         place = 0;
         for(int i = 0; i < fruits.length; i++ ) {
             if(affordability[place] < affordability[i]) place = i;
         }
         System.out.print("The most affordable fruit is: ");
         displayFruit();
         System.out.println();
     }
     /**
      * displayAccessibility method
      * Prints out the most accessible fruit (ie. the easiest to be eaten)
      */
     public void displayAccessibility() {
         System.out.println();
         place = 0;
         for(int i = 0; i < fruits.length; i++ ) {
             if(accessibility[place] < accessibility[i]) place = i;
         }
         System.out.print("The most accessible fruit is: ");
         displayFruit();
         System.out.println();
     }
 
 
     /**
      * displayAvailability method
      * Prints out the most available fruit (ie. the easiest to find in a grocery store)
      */
     public void displayAvailability() {
         System.out.println();
         place = 0;
         for(int i = 0; i < fruits.length; i++ ) {
             if(availability[place] < availability[i]) place = i;
         }
         System.out.print("The most widely available fruit is: ");
         displayFruit();
         System.out.println();
     }
 
 
     /**
      * displayNutrition method
      * Prints out the most nutritious fruit
      */
     public void displayNutrition() {
         System.out.println();
         place = 0;
         for(int i = 0; i < fruits.length; i++ ) {
             if(nutrition[place] < nutrition[i]) place = i;
         }
         System.out.print("The most nutritious fruit is: ");
         displayFruit();
         System.out.println();
     }
    
     /**
      * displayBest method
      * Prints out the overall best fruit (most well rounded) by calculating the weighted average
      */
     public void displayBest() {
         System.out.println();
         place = 0;
         double val = 0;
         for(int i = 0; i < fruits.length; i++ ) {
             val = (0.3*sweetness[place] + 0.2*affordability[place] + 0.1*accessibility[place] + 0.2*availability[place] + 0.2*nutrition[place]);
             if(val < (0.3*sweetness[i] + 0.2*affordability[i] + 0.1*accessibility[i] + 0.2*availability[i] + 0.2*nutrition[i])) place = i;
         }
         System.out.print("The most well-rounded fruit is: ");
         displayFruit();
         System.out.println();
     }
 
 
     /**
      * displayFruit method
      * Prints the information about the pre-chosen fruit
      */
     public void displayFruit() {
         System.out.println();
         System.out.println(fruits[place]);
         System.out.println("Sweetness: " + sweetness[place]);
         System.out.println("Affordability: " + affordability[place]);
         System.out.println("Accessibility: " + accessibility[place]);
         System.out.println("Availability: " + availability[place]);
         System.out.println("Nutrition: " + nutrition[place]);
         System.out.print("Overall Score: ");
         System.out.print(Math.round((0.3*sweetness[place] + 0.2*affordability[place] + 0.1*accessibility[place] + 0.2*availability[place] + 0.2*nutrition[place])* 100.0) / 100.0);
     }
 
 
     /**
      * exit method
      * Exits the program and prints a message for the user
      */
     public void exit(){
         System.out.println();
         System.out.println("Thanks for using the program!");
         System.out.println("Made by Avery Lee, Avery Mai, and Jessica Chen");
         System.out.println("03/02/2023");
     }
 } //ending of the program