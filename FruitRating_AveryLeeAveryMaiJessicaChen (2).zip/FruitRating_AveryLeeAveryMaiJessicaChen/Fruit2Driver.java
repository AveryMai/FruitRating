/**
 * Teacher: Ms. Krasteva
 * Assignment: This program ranks a large variety of fruits with five different categories to place them in and
 * calculates weighted averages
 * @author Avery Mai, Avery Lee, Jessica Chen
 * @version 03/03/2023
 */

public class Fruit2Driver extends Fruit2 {
    
     /**
     * Main method for part 2 of the assignment
     * Calls methods from Fruit2 class
     */
    public static void main(String[]args){
        Fruit2 f = new Fruit2();
        f.fromFile();
        f.displayTitle();
        f.mainMenu();
    }
}